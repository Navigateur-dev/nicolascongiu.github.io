﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatistiquesEntreesTableau
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] lesEntrees;
            float[] lesRecettes;
            string[] lesMois = { "janvier", "février", "mars", "avril", "mai", "juin",
                "juillet", "août", "septembre", "octobre", "novembre", "décembre" };
            string valeurSaisie;
            float nbTotEntrees;
            int ind;
            int cpt = 0;
            int max = 0;
            int nbMois = 0;
            int anneeEnCours;
            int anneeAnterieure = 0;
            float nbRecetteMin;
            float nbRecetteMax = 0f;
            float nbTotRecettes;
            float nbRecetteMoy = 0f;
            int userSaisie;


            do
            {
                Console.Write("Veuillez indiquer le nombre de mois de la période pour laquelle vous souhaitez saisir le nombre d'entrées : ");
                valeurSaisie = Console.ReadLine();
                int.TryParse(valeurSaisie, out nbMois);
                if (nbMois < 1 || nbMois > 12)
                {
                    Console.Write("Erreur de saisie : le nombre de mois doit être compris entre 1 et 12");
                }

            } while (nbMois < 1 || nbMois > 12);


            lesEntrees = new int[nbMois];
            lesRecettes = new float[nbMois];

            anneeEnCours = DateTime.Now.Year;
            anneeAnterieure = anneeEnCours - 1;
            Console.WriteLine("Vous allez saisir le nombre d'entrées réalisées sur l'année : " + anneeAnterieure);


            for (ind = 0; ind < lesEntrees.Length; ind++)
            {
                Console.WriteLine("Saisissez le nombre d'entrées pour " + lesMois[ind] + " : ");
                valeurSaisie = Console.ReadLine();
                int.TryParse(valeurSaisie, out lesEntrees[ind]);
            }

            nbTotEntrees = 0;
            for (ind = 0; ind < lesEntrees.Length; ind++)
            {
                nbTotEntrees = nbTotEntrees + lesEntrees[ind];
            }

            for (ind = 0; ind < lesEntrees.Length; ind++)
            {
                if (lesEntrees[ind] > 1000)
                {
                    cpt++;
                }
                Console.WriteLine(cpt + " mois ont eu plus de 1000 entrées ");
            }

            for (ind = 0; ind < lesEntrees.Length; ind++)
            {
                if (lesEntrees[ind] > max)
                {
                    max = lesEntrees[ind];

                }
            }

            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                Console.WriteLine("Saisissez la recette pour : " + lesMois[ind] + " : ");
                valeurSaisie = Console.ReadLine();
                float.TryParse(valeurSaisie, out lesRecettes[ind]);

            }

            nbTotRecettes = 0f;
            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                nbTotRecettes = nbTotRecettes + lesRecettes[ind];
            }

            nbRecetteMax = 0f;
            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                if (lesRecettes[ind] > nbRecetteMax)
                {
                    nbRecetteMax = lesRecettes[ind];

                }
            }
            nbRecetteMin = 99999999f;
            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                if (lesRecettes[ind] < nbRecetteMin)
                {
                    nbRecetteMin = lesRecettes[ind];

                }
            }
            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                nbRecetteMoy = nbTotRecettes / nbMois;
            }
            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                if (lesRecettes[ind] > 499 && lesRecettes[ind] < 1501)
                {
                    Console.WriteLine("Mois ayant une recette compris entre 500 et 1500 : " + lesMois[ind]);
                }

            }

            Console.WriteLine("Veuillez saisir le montant pour voir les recettes supérieurs :  ");
            valeurSaisie = Console.ReadLine();
            int.TryParse(valeurSaisie, out userSaisie);

            for (ind = 0; ind < lesRecettes.Length; ind++)
            {
                if (lesRecettes[ind] > userSaisie)
                {
                    Console.WriteLine("Montant supérieur à la saisie : " + lesMois[ind]);

                }
            }


            //
            Console.WriteLine("\nMontant total de recettes pour l'année " + anneeAnterieure + " : " + nbTotRecettes);
            Console.WriteLine("Le max d'entrée est de : " + max);
            Console.WriteLine("La recette la plus faible est de : " + nbRecetteMin + " et la plus élevé est de " + nbRecetteMax);
            Console.WriteLine("\nMontant total d'entrées pour l'année " + anneeAnterieure + " : " + nbTotEntrees);
            Console.WriteLine("\n La moyenne sera de " + nbRecetteMoy);
            Console.WriteLine("\nAppuyez sur entrée pour arrêter le programme");
            Console.ReadLine();
        }
    }
}

<?php
$hote = 'local'; // nom ou adresse ip du serveur h�bergeant le SGBD MySQL
$utilisateur = 'employe'; // compte de connexion utilis� par l'application
$mdp = 'employe@7883_frincERE'; // mot de passe du compte de connexion
$nombdd = 'bd_gesagence_slam'; // nom de la base de donn�es

try {
	//cr�ation d'un objet qui sera utilis� pour travailler avec la base de donn�es
	$bdd=new PDO("mysql:host=$hote;dbname=$nombdd;charset=utf8", $utilisateur, $mdp);
	
	//mode de fetch  =  FETCH_OBJ (on r�cup�re les donn�es dans des objets)
	$bdd->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

	//Activation des erreurs PDO
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $err){
	die("BDAcc erreur de connexion � la base de donn�es.<br>Erreur :". $err->getMessage());
}
?>
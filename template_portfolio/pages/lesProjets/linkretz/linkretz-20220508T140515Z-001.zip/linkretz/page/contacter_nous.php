<!DOCTYPE html>
<html lang="fr-FR">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale-1.0">
    <meta name="description" content="Site de l'agence Linkretz">
    <link rel="stylesheet" href="../css/style.css">
    <title>Site de l'agence Linkretz - Page d'accueil</title>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/header.html';?>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/menu_client.html'; ?>
    <section class="accueil">
    
        <h2>Demande d'information</h2>
        
        <div class="sec">
            

        </div>
    </section>
    


    </section>
    <section class="table">
		    <p class="table">
			    <h2>Horaires d'ouverture</h2><br>
			    <table>
			        <?php
				         include "include/connexion_bd_insert.php";
                         // ex�cution de la requ�te : on r�cup�re le r�sultat
                        try {
                            // on pr�pare la requ�te INSERT dans la table client
                            $req = $bdd->prepare("insert into client values(0, :nom, :mail, :connaissance_entreprise, :rencontre, :decouverte_site, :loisir, :info_envoie, :remarque)");
                            // on affecte une valeur � chacun des param�tres d�clar�s dans la requ�te INSERT
                            $req->bindValue(':nom', $_POST['txtNom'], PDO::PARAM_STR);
                            $req->bindValue(':mail', $_POST['txtMail'], PDO::PARAM_STR);
                            $req->bindValue(':connaissance_entreprise', $_POST['txtCoEntrep'], PDO::PARAM_STR);
                            $req->bindValue(':rencontre', $_POST['txtMeet'], PDO::PARAM_STR);
                            $req->bindValue(':decouverte_site', $_POST['txtDecouvSite'], PDO::PARAM_STR);
                            $req->bindValue(':loisir', $_POST['txtLoisir'], PDO::PARAM_STR);
                            $req->bindValue(':info_envoie', $_POST['txtEnvoie'], PDO::PARAM_STR);
                            $req->bindValue(':remarque', $_POST['txtRemarque'], PDO::PARAM_STR);
                            // on demande l'ex�cution de la requ�te INSERT
                            $req->execute();
                            // on v�rifie que l�on a bien ajout� un client
                            if ($req->rowCount() == 0) {
                                echo("Erreur grave : le client n�a pas �t� enregistr�.") ;
                            } else {
                                echo("Le client a �t� enregistr�.") ;
                           } catch(PDOException $err){
                                die("BDIns01:erreur lors de l�insert dans la table client � script client_ajout.php
                                    <br>Erreur :" . $err->getMessage());
                    ?>    
			        
			    </table> 
		    </p>
		</section>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/footer.html'; ?>
</body>
</html>

<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<meta charset="UTF-8">
	<meta name ="viewport" content="width=device-width, initial-scale-1.0">
	<meta name="description" content="Site de l'agence Linkretz">
	<link rel="stylesheet" href="../../css/style.css">
	<title>Site de l'agence Linkretz - Page d'accueil</title>
</head>
<body>	

	<?php
		include $_SERVER['DOCUMENT_ROOT'].'/include/header.html';
	?>	
    <?php 
        include $_SERVER['DOCUMENT_ROOT'].'/include/menu_admin.html'; 
    ?>

		<section class="accueil">
			<h2>Bienvenue dans l'espace dédié aux administratifs </h2>
        </section>
         
</body>     
</html>
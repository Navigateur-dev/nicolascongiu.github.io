<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<meta charset="UTF-8">
	<meta name ="viewport" content="width=device-width, initial-scale-1.0">
	<meta name="description" content="Site de l'agence Linkretz">
	<link rel="stylesheet" href="../../css/style.css">
	<title>Site de l'agence Linkretz - Gestion des tour-opérateurs</title>
</head>
<body>
	<?php include "../../include/header.html";?>
	<?php include "../../include/menu_client.html"; ?>
	<section class="jaune">
		<h2>Gestion des tour-opérateurs</h2>
		<div class="sec">
			<div class="boutonadd">
            <a href='tour_operateur_ajout.php'>
                <input type='button' name='AjoutEmp' value='Ajouter un tour-operateur'/>
            </a>
			<p></p>
			<?php
				include "../../include/connexion_bd.php";
				// exécution de la requête : on récupère le résultat
				try {
					$lesEnregs=$bdd->query("SELECT nom, libelle FROM tour_operateur JOIN specialite ON id_specialite = specialite.id");
				}catch (PDOException $e) {
					die ("Err BDSelect : erreur de lecture table tour_operateur dans tour_operateur_consult.php<br>Message d'erreur :" . $e->getMessage());
				}
				// on teste si le SELECT a retourné des enregistrements
				if($lesEnregs->rowCount () ==0) {
					echo ("Aucun tour-opérateur n'a été enregistré");
				} else {
					// on lit le tableau retourné et pour chaque enregistrement, on affiche le nom et le libelle
					echo'<table>
							<tr>
                            <th>Nom</th>
                            <th>Spécialité</th>
                            <th>Modifier</th>
                            <th>Supprimer</th>
                            </tr>    
                        ';
                        foreach ($lesEnregs as $enreg) {
                        echo "<tr><td>$enreg->nom</td>
                        <td>$enreg->libelle</td>
                        <td><a href='tour_operateur_modifier.php'> <input type='button' name='ModifEmp' value='Modifier'/></td>
                        <td><a href='tour_oprateur_supprimer.php'> <input type='button' name='SupprimEmp' value='Supprimer'/></tr>";               
                        }
                        echo '</table>';
						}
				
			?>
		</div>
	</section>
	<?php include "../../include/footer.html";?>
</body>
</html>
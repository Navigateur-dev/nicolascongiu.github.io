<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<meta charset="UTF-8">
	<meta name ="viewport" content="width=device-width, initial-scale-1.0">
	<meta name="description" content="Site de l'agence Linkretz">
	<link rel="stylesheet" href="../../css/style.css">
	<title>Site de l'agence Linkretz - Gestion des employés</title>
</head>
<body>
    <?php
	include $_SERVER['DOCUMENT_ROOT'].'/include/header.html';
    ?>	
    <?php 
        include $_SERVER['DOCUMENT_ROOT'].'/include/menu_admin.html'; 
    ?>
    <section>
        <h2>Suppression d'un tour-opérateur</h2>
		<div class="sec">
			<h3>En cours de construction</h3>
		</div>
    </section>
    <?php
		include $_SERVER['DOCUMENT_ROOT'].'/include/footer_admin.html';
	?>	
	
</body>
</html>
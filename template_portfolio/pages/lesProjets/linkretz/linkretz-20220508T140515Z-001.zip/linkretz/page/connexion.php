﻿<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<meta charset="UTF-8">
	<meta name ="viewport" content="width=device-width, initial-scale-1.0">
	<meta name="description" content="Site de l'agence Linkretz">
	<link rel="stylesheet" href="../css/style.css">
	<title>Site de l'agence Linkretz - Liste des tour-opérateurs</title>
</head>
<body>
	<?php include "../include/header.html";?>
	<?php include "../include/menu_client.html"; ?>
	<section class="red">
		<h2>Connexion</h2>
		<div class="sec">
			<p><a href="/page/panel_employe.php">Accès au menu des salariés<a></p>
			<p><a href="/page/admin/panel_admin.php">Accès au menu administatif<a></p>
		</div>
	</section>
	<?php include "../include/footer.html";?>
</body>
</html>
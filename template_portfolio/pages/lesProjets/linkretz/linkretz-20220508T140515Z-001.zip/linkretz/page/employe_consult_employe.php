<!DOCTYPE html>
<html lang="fr-FR">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale-1.0">
    <meta name="description" content="Site de l'agence Linkretz">
    <link rel="stylesheet" href="../css/style.css">
    <title>Site de l'agence Linkretz - Page employé</title>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/header.html';?>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/menu_employés.html'; ?>
    <section class="red">
		<h2>Liste des employés</h2>
		<div class="sec">
			<section class="table">
		    <p class="table">
			    <table>
			        <?php
				         include "../include/connexion_bd.php";
                         // exécution de la requête : on récupère le résultat
                        try {
                            $lesEnregs=$bdd->query("SELECT nom, prenom, libelle, telephone FROM employe JOIN fonction ON idfonction = fonction.id;");   
                        } catch (PDOException $e) {
                           die ("Err BDSelect : erreur de lecture table employe dans employe_consult_client.php<br>Message d'erreur :" . $e->getMessage());
                        }
                          // on teste si le SELECT a retourné des enregistrements
                        if($lesEnregs->rowCount () ==0) {
                          echo ("Aucun employe n'a été enregistré");
                        } else {
                                echo'<table>
                                    <tr>
                                        <th>Nom</th>
                                        <th>Prénom</th>
                                        <th>Fonction</th>
                                        <th>Téléphone</th>
                                    </tr>    
                                ';
                                foreach ($lesEnregs as $enreg) {
                                    echo "<tr><td>$enreg->nom</td><td>$enreg->prenom</td><td>$enreg->libelle</td><td>$enreg->telephone</td></tr>";               
                                }
                                echo '</table>';
                        }
                    ?>    
			        
			    </table> 
		    </p>
		</section>
		</div>
	</section>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/include/footer.html'; ?>
</body>
</html>